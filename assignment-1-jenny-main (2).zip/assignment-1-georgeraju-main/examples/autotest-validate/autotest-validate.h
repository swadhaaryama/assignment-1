#include <stdbool.h>
#include <stdio.h>
#include <string.h>

bool this_function_returns_true();
bool this_function_returns_false();
const char *my_username();
